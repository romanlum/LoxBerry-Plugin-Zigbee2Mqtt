# LoxBerry Unifi controller plugin
Plugin for install unifi controller and integrate webui into loxberry

### Documentation

Coming soon.

### License

Licensed under the [MIT](LICENSE) License.

thx@poppins
![LoxBerry Poppins](https://user-images.githubusercontent.com/3605512/72895177-1bebb700-3d1d-11ea-8393-7e9f3a7a0207.png)
